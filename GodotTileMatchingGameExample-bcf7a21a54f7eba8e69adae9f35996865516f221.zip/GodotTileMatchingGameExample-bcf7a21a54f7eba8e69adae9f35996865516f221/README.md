The tutorial for this project is here (made by me): https://youtu.be/94r4mvvccsg

All my demos are on the Asset Library: https://godotengine.org/asset-library/asset?user=ThinkWithGames